=== Mormat Scheduler ===
Contributors: Mathieu Morel
Tags: post type, content types, custom post types, scheduler, beta
Requires at least: 6.1
Tested up to:      6.1
Requires PHP:      7.2
License: GPLv2 or later
Stable tag: 0.0.1

Provides a custom type that displays a scheduler with events

== Description ==

To create a new scheduler :
- go to the admin dashboard 
- click on "Schedulers" then on "Add a scheduler"
- create some events in the "Events Manager" box
- click on "publish"
- click on the permalink to see the results
